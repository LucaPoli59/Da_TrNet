# Unofficial Deutsche Bahn Fernverkehr (German Railways Long-Distance Trains) Timetable GTFS Feed For 2019

From 2018-12-09 to 2019-12-14.

```
nohup ./db_to_gtfs.py --api-key <API_KEY> --start-date 2018-12-09 --end-date 2019-12-15 > std.txt 2> err.txt &
```